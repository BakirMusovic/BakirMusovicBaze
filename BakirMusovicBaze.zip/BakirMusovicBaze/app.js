var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
var logger = require('morgan');
const mysql = require('mysql2');
const PORT = 3000;

const db = require('./mysql/config');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
const router = express.Router();


var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

app.use(bodyParser.json());

app.get('/radni-nalozi', (req, res) => {
  db.query('SELECT * FROM radniNalog', (err, results) => {
    if (err) {
      console.error('Greška pri dohvatanju radnih naloga:', err);
      res.status(500).send('Greška pri dohvatanju radnih naloga');
    } else {
      res.render('radniNalozi', { radniNalozi: results });
    }
  });
});

app.get('/registrovana-vozila-get', (req, res) => {
  db.query('SELECT * FROM registarVozila', (err, results) => {
    if (err) {
      console.error('Greška pri dohvatanju registrovanih vozila:', err);
      res.status(500).send('Greška pri dohvatanju registrovanih vozila');
    } else {
      res.render('registarVozila', { registarVozila: results });
    }
  });
});

app.get('/dodaj-vozilo', (req, res) => {
  res.render('dodajVozilo');
});

app.post('/dodaj-vozilo', (req, res) => {
  const novoVozilo = {
    sifraDrzave: req.body.sifraDrzave,
    sifraTipa: req.body.sifraTipa,
    sifraMarke: req.body.sifraMarke,
    brojRegistracije: req.body.brojRegistracije,
    modelVozila: req.body.modelVozila,
  };

  db.query('INSERT INTO registarVozila SET ?', novoVozilo, (err, results) => {
    if (err) {
      console.error('Greška pri dodavanju novog vozila:', err);
      res.status(500).send('Greška pri dodavanju novog vozila');
    } else {
      res.redirect('/registrovana-vozila-get');
    }
  });
});

app.get('/registrovana-vozila-delete', (req, res) => {
  res.render('deleteRegistarVozila');
});

app.post('/registrovana-vozila-delete', (req, res) => {
  const voziloId = req.body.sifraVozila;

  db.query('DELETE FROM registarVozila WHERE sifraVozila = ?', voziloId, (err, results) => {
    if (err) {
      console.error('Greška pri brisanju vozila:', err);
      res.status(500).send('Greška pri brisanju vozila');
    } else {
      res.redirect('/registrovana-vozila-get');
    }
  });
});
const radniNalozi = '';
app.get('/izaberi-radni-nalog', async (req, res) => {
  try {
    const results = await db.promise().query('SELECT brojRadnogNaloga FROM radniNalog');
    const radniNalozi = results[0];

    res.render('izaberiRadniNalog', { radniNalozi });
    console.log(radniNalozi);
  } catch (error) {
    console.error('Greška pri dohvatanju radnih naloga:', error);
    res.status(500).send('Greška pri dohvatanju radnih naloga');
  }
});

app.get('/prikazi-radni-nalog', async (req, res) => {
  const brojRadnogNaloga = req.query.brojRadnogNaloga;

  try {
    const results = await db.promise().query(`
      SELECT
        rn.brojRadnogNaloga,
        rn.datumZaduzenjaVozila,
        rn.trajanjePopravkaUDanima,
        rn.zapazanja,
        rn.registracija,
        rn.brojSasije,
        rn.sifraKupca,
        rn.sifraVozila,
        rn.sifraUsluge,
        rn.idZaposlenika,
        rn.sifraCjenovnika,
        us.imeUsluge AS nazivUsluge,
        z.imeIprezimeZaposlenika
      FROM
        radniNalog rn
        LEFT JOIN uslugaServisa us ON rn.sifraUsluge = us.sifraUsluge
        LEFT JOIN zaposlenik z ON rn.idZaposlenika = z.idZaposlenika
      WHERE
        rn.brojRadnogNaloga = ?;
    `, [brojRadnogNaloga]);

    const detaljiRadnogNaloga = results[0][0]; // Dobijte prvi red rezultata
    res.render('detaljiRadnogNaloga', { detaljiRadnogNaloga });
  } catch (error) {
    console.error('Greška pri dohvatanju detalja radnog naloga:', error);
    res.status(500).send('Greška pri dohvatanju detalja radnog naloga');
  }
});



app.use(function(req, res, next) {
  next(createError(404));
});

app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

app.listen(PORT, () => {
  console.log(`Server je pokrenut na portu ${PORT}`);
});

module.exports = app;
module.exports = router;

