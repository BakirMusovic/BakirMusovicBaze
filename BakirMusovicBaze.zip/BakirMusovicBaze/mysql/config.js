const mysql = require("mysql2");
const dotenv = require('dotenv');
dotenv.config();
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATEBASE,
    port: process.env.DB_PORT
});

db.connect((err) => {
    if (err) {
        console.error('Greška pri povezivanju s bazom podataka:', err);
    } else {
        console.log('Uspješno povezan s bazom podataka');
    }
});

module.exports = db;